# HXZ DOW

Aplikasi Android untuk download video (tanpa watermark), MP3, cover, dan foto slideshow dari link TikTok.

## Fitur
- Layout portrait 9:16, background gambar, tombol & kartu bergaya kaca (glassmorphism)
- Intro video saat app dibuka (bisa dimatikan di Setelan, ada tombol Lewati)
- Video HD / SD, MP3, cover, dan foto slideshow
- Deteksi link otomatis dari clipboard
- Bagikan dari TikTok langsung ke HXZ DOW (Share → HXZ DOW)
- Pratinjau video sebelum unduh, progres + tombol batal
- Riwayat: putar, bagikan, hapus
- Simpan ke galeri: Movies/HXZ DOW, Music/HXZ DOW, Pictures/HXZ DOW

## Build APK lewat GitHub
1. Buat repo baru di GitHub, lalu upload seluruh isi folder ini (atau `git push`).
2. Buka tab **Actions** → workflow **Build APK** jalan otomatis (atau klik *Run workflow*).
3. Selesai (±5–8 menit): ambil `HXZ-DOW.apk` dari **Releases** atau dari *Artifacts* run tersebut.

## Catatan
- Data video diambil dari API publik tikwm.com, jadi butuh internet dan bisa kena batas laju.
- Unduh hanya konten milikmu atau yang sudah mendapat izin kreator.
