#!/usr/bin/env python3
"""Dijalankan CI setelah `flutter create`: pasang izin, label app, intent Share,
dan ganti MainActivity dengan versi HXZ DOW (simpan ke MediaStore + terima Share)."""
import pathlib
import re
import sys

main = pathlib.Path("android/app/src/main")
manifest = main / "AndroidManifest.xml"
s = manifest.read_text(encoding="utf-8")

perms = (
    '    <uses-permission android:name="android.permission.INTERNET"/>\n'
    '    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>\n'
    '    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28"/>\n'
)
if "android.permission.INTERNET" not in s:
    s = s.replace(
        "<application",
        perms + '    <application\n        android:usesCleartextTraffic="true"',
        1,
    )

s = re.sub(r'android:label="[^"]*"', 'android:label="HXZ DOW"', s, count=1)

share_filter = (
    "            <intent-filter>\n"
    '                <action android:name="android.intent.action.SEND"/>\n'
    '                <category android:name="android.intent.category.DEFAULT"/>\n'
    '                <data android:mimeType="text/plain"/>\n'
    "            </intent-filter>\n"
)
if "android.intent.action.SEND" not in s:
    s = s.replace("</activity>", share_filter + "        </activity>", 1)

manifest.write_text(s, encoding="utf-8")

# MainActivity
found = list(main.glob("**/MainActivity.kt"))
if not found:
    sys.exit("MainActivity.kt tidak ditemukan")
target = found[0]
pkg = re.search(r"^package\s+([\w.]+)", target.read_text(encoding="utf-8"), re.M)
if not pkg:
    sys.exit("package MainActivity tidak ditemukan")
src = pathlib.Path("android_overrides/MainActivity.kt").read_text(encoding="utf-8")
target.write_text(src.replace("__PACKAGE__", pkg.group(1)), encoding="utf-8")
print("patched:", manifest, target, "package", pkg.group(1))
