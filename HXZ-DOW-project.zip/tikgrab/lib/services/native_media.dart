import 'package:flutter/services.dart';

/// Jembatan ke Kotlin (MainActivity): simpan ke galeri/Musik + terima Share.
class NativeMedia {
  static const _ch = MethodChannel('tikgrab/media');

  /// Dipanggil saat user membagikan link dari TikTok ke HXZ DOW (app sudah jalan).
  static void Function(String text)? onShared;

  static void init() {
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'sharedText') {
        final t = call.arguments as String?;
        if (t != null && t.isNotEmpty) onShared?.call(t);
      }
      return null;
    });
  }

  static Future<void> openUrl(String url) async {
    try {
      await _ch.invokeMethod<void>('openUrl', {'url': url});
    } catch (_) {}
  }

  static Future<String?> getSharedText() async {
    try {
      return await _ch.invokeMethod<String>('getSharedText');
    } catch (_) {
      return null;
    }
  }

  /// kind: 'video' -> Movies/HXZ DOW, 'audio' -> Music/HXZ DOW, 'image' -> Pictures/HXZ DOW
  static Future<String?> save({
    required String path,
    required String name,
    required String mime,
    required String kind,
  }) {
    return _ch.invokeMethod<String>('saveToMedia', {
      'path': path,
      'name': name,
      'mime': mime,
      'kind': kind,
    });
  }
}
