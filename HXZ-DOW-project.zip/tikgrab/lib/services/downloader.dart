import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class CancelToken {
  bool cancelled = false;
  void cancel() => cancelled = true;
}

class CancelledException implements Exception {
  @override
  String toString() => 'Dibatalkan';
}

class Downloader {
  static const userAgent =
      'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';

  static Future<Directory> cacheDir() async {
    final base = await getApplicationSupportDirectory();
    final d = Directory('${base.path}/tikgrab');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  static Future<int> cacheSize() async {
    var total = 0;
    try {
      final d = await cacheDir();
      await for (final e in d.list()) {
        if (e is File) total += await e.length();
      }
    } catch (_) {}
    return total;
  }

  static Future<void> clearCache() async {
    try {
      final d = await cacheDir();
      await for (final e in d.list()) {
        if (e is File) {
          try {
            await e.delete();
          } catch (_) {}
        }
      }
    } catch (_) {}
  }

  static Future<File> download(
    String url,
    String savePath, {
    CancelToken? cancel,
    void Function(int got, int total)? onProgress,
  }) async {
    final client = http.Client();
    final file = File(savePath);
    IOSink? sink;
    try {
      final req = http.Request('GET', Uri.parse(url));
      req.headers['User-Agent'] = userAgent;
      req.headers['Referer'] = 'https://www.tiktok.com/';
      final res = await client.send(req).timeout(const Duration(seconds: 30));
      if (res.statusCode >= 400) {
        throw Exception('Server membalas ${res.statusCode}');
      }
      final total = res.contentLength ?? 0;
      sink = file.openWrite();
      var got = 0;
      await for (final chunk in res.stream) {
        if (cancel?.cancelled ?? false) throw CancelledException();
        sink.add(chunk);
        got += chunk.length;
        onProgress?.call(got, total);
      }
      await sink.flush();
      await sink.close();
      sink = null;
      if (got == 0) throw Exception('File kosong');
      return file;
    } catch (_) {
      try {
        await sink?.close();
      } catch (_) {}
      try {
        if (await file.exists()) await file.delete();
      } catch (_) {}
      rethrow;
    } finally {
      client.close();
    }
  }
}
