import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../models.dart';

class ApiException implements Exception {
  ApiException(this.message, {this.retry = false});
  final String message;
  final bool retry;
  @override
  String toString() => message;
}

class TikApi {
  static const _headers = {
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36',
    'Accept': 'application/json',
  };

  /// Ambil link TikTok dari teks bebas (mis. teks hasil "Bagikan" TikTok).
  static String? extractUrl(String text) {
    for (final m in RegExp(r'https?://[^\s]+').allMatches(text)) {
      final u = m.group(0)!.replaceAll(RegExp(r'[)\]>.,;!]+$'), '');
      final host = Uri.tryParse(u)?.host.toLowerCase() ?? '';
      if (host == 'tiktok.com' || host.endsWith('.tiktok.com')) return u;
    }
    final bare = RegExp(r'(?:[a-z0-9]+\.)?tiktok\.com/[^\s]+', caseSensitive: false)
        .firstMatch(text);
    if (bare != null) {
      final cleaned = bare.group(0)!.replaceAll(RegExp(r'[)\]>.,;!]+$'), '');
      return 'https://$cleaned';
    }
    return null;
  }

  static Future<TikInfo> fetch(String url) async {
    Object? lastErr;
    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        final uri = Uri.https('www.tikwm.com', '/api/', {'url': url, 'hd': '1'});
        final res =
            await http.get(uri, headers: _headers).timeout(const Duration(seconds: 25));
        if (res.statusCode != 200) {
          throw ApiException('Server membalas ${res.statusCode}', retry: true);
        }
        final body = jsonDecode(utf8.decode(res.bodyBytes));
        if (body is! Map) throw ApiException('Respons server tidak valid');
        if (body['code'] == 0 && body['data'] is Map) {
          return TikInfo.fromJson(Map<String, dynamic>.from(body['data'] as Map));
        }
        final msg = '${body['msg'] ?? 'Gagal mengambil video'}';
        final limited = msg.toLowerCase().contains('limit');
        throw ApiException(
          limited ? 'Server sibuk, coba lagi sebentar' : msg,
          retry: limited,
        );
      } on ApiException catch (e) {
        if (!e.retry) rethrow;
        lastErr = e;
        await Future.delayed(const Duration(milliseconds: 1400));
      } catch (e) {
        lastErr = e;
        await Future.delayed(const Duration(milliseconds: 800));
      }
    }
    throw ApiException(_friendly(lastErr));
  }

  static String _friendly(Object? e) {
    if (e is ApiException) return e.message;
    if (e is SocketException) return 'Tidak ada koneksi internet';
    if (e is TimeoutException) return 'Koneksi terlalu lambat (timeout)';
    return 'Gagal mengambil video. Pastikan link benar & publik.';
  }
}
