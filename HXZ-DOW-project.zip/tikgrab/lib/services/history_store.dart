import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models.dart';

class HistoryStore {
  static const _key = 'history_v1';

  /// Dinaikkan setiap kali riwayat berubah, supaya tab Riwayat refresh.
  static final ValueNotifier<int> changes = ValueNotifier<int>(0);

  static Future<List<HistoryItem>> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString(_key);
      if (raw == null) return [];
      final list = jsonDecode(raw) as List;
      return list
          .map((e) => HistoryItem.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> _save(List<HistoryItem> items) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, jsonEncode(items.map((e) => e.toJson()).toList()));
    changes.value++;
  }

  static Future<void> add(HistoryItem item) async {
    final l = await load();
    l.insert(0, item);
    if (l.length > 200) l.removeRange(200, l.length);
    await _save(l);
  }

  static Future<void> remove(HistoryItem item) async {
    final l = await load();
    l.removeWhere((e) => e.path == item.path && e.time == item.time);
    await _save(l);
    try {
      final f = File(item.path);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }

  static Future<void> clear() async {
    await _save([]);
  }
}
