import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings extends ChangeNotifier {
  AppSettings._();
  static final AppSettings instance = AppSettings._();

  SharedPreferences? _p;
  bool autoPaste = true;
  bool playIntro = true;
  bool haptics = true;

  Future<void> load() async {
    try {
      _p = await SharedPreferences.getInstance();
      autoPaste = _p!.getBool('autoPaste') ?? true;
      playIntro = _p!.getBool('playIntro') ?? true;
      haptics = _p!.getBool('haptics') ?? true;
    } catch (_) {}
  }

  void setAutoPaste(bool v) {
    autoPaste = v;
    _p?.setBool('autoPaste', v);
    notifyListeners();
  }

  void setPlayIntro(bool v) {
    playIntro = v;
    _p?.setBool('playIntro', v);
    notifyListeners();
  }

  void setHaptics(bool v) {
    haptics = v;
    _p?.setBool('haptics', v);
    notifyListeners();
  }
}
