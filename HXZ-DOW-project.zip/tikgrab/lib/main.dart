import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'services/native_media.dart';
import 'services/settings.dart';
import 'ui/home_shell.dart';
import 'ui/intro_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Layout 9:16 -> selalu portrait.
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  await AppSettings.instance.load();
  NativeMedia.init();
  runApp(const TikGrabApp());
}

class TikGrabApp extends StatelessWidget {
  const TikGrabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HXZ DOW',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF3B82F6),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: Colors.black,
      ),
      home: AppSettings.instance.playIntro
          ? const IntroPage()
          : const HomeShell(),
    );
  }
}
