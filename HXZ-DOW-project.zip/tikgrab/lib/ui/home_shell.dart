import 'package:flutter/material.dart';

import '../services/native_media.dart';
import 'download_tab.dart';
import 'glass.dart';
import 'history_tab.dart';
import 'settings_tab.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final _downloadKey = GlobalKey<DownloadTabState>();

  @override
  void initState() {
    super.initState();
    NativeMedia.onShared = _onShared;
    // Link yang dibagikan dari TikTok saat app belum berjalan.
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final t = await NativeMedia.getSharedText();
      if (t != null && t.isNotEmpty) _onShared(t);
    });
  }

  @override
  void dispose() {
    NativeMedia.onShared = null;
    super.dispose();
  }

  void _onShared(String text) {
    if (!mounted) return;
    setState(() => _index = 0);
    _downloadKey.currentState?.handleIncoming(text, autoStart: true);
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).padding.bottom;
    return Scaffold(
      extendBody: true,
      backgroundColor: Colors.black,
      body: AppBackground(
        child: SafeArea(
          bottom: false,
          child: IndexedStack(
            index: _index,
            children: [
              DownloadTab(key: _downloadKey),
              const HistoryTab(),
              const SettingsTab(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.fromLTRB(20, 0, 20, 12 + bottomInset),
        child: GlassBox(
          radius: 30,
          blur: 22,
          strength: 1.2,
          padding: const EdgeInsets.all(6),
          child: Row(
            children: [
              _NavItem(
                icon: Icons.download_rounded,
                label: 'Unduh',
                selected: _index == 0,
                onTap: () => setState(() => _index = 0),
              ),
              _NavItem(
                icon: Icons.history_rounded,
                label: 'Riwayat',
                selected: _index == 1,
                onTap: () => setState(() => _index = 1),
              ),
              _NavItem(
                icon: Icons.tune_rounded,
                label: 'Setelan',
                selected: _index == 2,
                onTap: () => setState(() => _index = 2),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            color: selected
                ? Colors.white.withValues(alpha: 0.28)
                : Colors.transparent,
            border: Border.all(
              color: selected
                  ? Colors.white.withValues(alpha: 0.45)
                  : Colors.transparent,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: Colors.white, size: 22),
              const SizedBox(height: 2),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
