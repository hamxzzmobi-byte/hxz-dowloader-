import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../services/downloader.dart';
import '../util.dart';
import 'glass.dart';

/// Pemutar kaca (video atau MP3) dari file lokal atau URL.
class PlayerSheet extends StatefulWidget {
  const PlayerSheet({
    super.key,
    this.filePath,
    this.url,
    required this.title,
    this.audio = false,
  });

  final String? filePath;
  final String? url;
  final String title;
  final bool audio;

  static Future<void> show(
    BuildContext context, {
    String? filePath,
    String? url,
    required String title,
    bool audio = false,
  }) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      builder: (_) => PlayerSheet(
        filePath: filePath,
        url: url,
        title: title,
        audio: audio,
      ),
    );
  }

  @override
  State<PlayerSheet> createState() => _PlayerSheetState();
}

class _PlayerSheetState extends State<PlayerSheet> {
  late final VideoPlayerController _c;
  bool _ready = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    if (widget.filePath != null) {
      _c = VideoPlayerController.file(File(widget.filePath!));
    } else {
      _c = VideoPlayerController.networkUrl(
        Uri.parse(widget.url ?? ''),
        httpHeaders: const {
          'User-Agent': Downloader.userAgent,
          'Referer': 'https://www.tiktok.com/',
        },
      );
    }
    _init();
  }

  Future<void> _init() async {
    try {
      await _c.initialize();
      await _c.setLooping(true);
      await _c.play();
      if (mounted) setState(() => _ready = true);
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Padding(
      padding: EdgeInsets.fromLTRB(
        12,
        0,
        12,
        12 + MediaQuery.of(context).padding.bottom,
      ),
      child: GlassBox(
        radius: 30,
        blur: 26,
        strength: 1.1,
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 42,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white54,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              widget.title.isEmpty ? 'HXZ DOW' : widget.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 10),
            if (_failed)
              const Padding(
                padding: EdgeInsets.all(28),
                child: Text(
                  'Tidak bisa memutar media ini.',
                  style: TextStyle(color: Colors.white70),
                ),
              )
            else if (!_ready)
              const Padding(
                padding: EdgeInsets.all(40),
                child: CircularProgressIndicator(color: Colors.white),
              )
            else if (widget.audio)
              Container(
                height: 140,
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white.withValues(alpha: 0.12),
                ),
                child: const Icon(
                  Icons.music_note_rounded,
                  size: 64,
                  color: Colors.white,
                ),
              )
            else
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: h * 0.58),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: AspectRatio(
                    aspectRatio:
                        _c.value.aspectRatio > 0 ? _c.value.aspectRatio : 9 / 16,
                    child: GestureDetector(
                      onTap: _toggle,
                      child: VideoPlayer(_c),
                    ),
                  ),
                ),
              ),
            if (_ready) ...[
              const SizedBox(height: 12),
              ValueListenableBuilder<VideoPlayerValue>(
                valueListenable: _c,
                builder: (_, v, __) => Row(
                  children: [
                    GlassButton(
                      label: '',
                      icon: v.isPlaying
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded,
                      compact: true,
                      expand: false,
                      onTap: _toggle,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: VideoProgressIndicator(
                        _c,
                        allowScrubbing: true,
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        colors: VideoProgressColors(
                          playedColor: Colors.white,
                          bufferedColor: Colors.white38,
                          backgroundColor: Colors.white12,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      '${fmtDuration(v.position)} / ${fmtDuration(v.duration)}',
                      style: const TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _toggle() {
    _c.value.isPlaying ? _c.pause() : _c.play();
  }
}
