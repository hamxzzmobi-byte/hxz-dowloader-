import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../models.dart';
import '../services/history_store.dart';
import '../util.dart';
import 'glass.dart';
import 'player_sheet.dart';

class HistoryTab extends StatefulWidget {
  const HistoryTab({super.key});

  @override
  State<HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends State<HistoryTab> {
  List<HistoryItem> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    HistoryStore.changes.addListener(_load);
    _load();
  }

  @override
  void dispose() {
    HistoryStore.changes.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final l = await HistoryStore.load();
    if (!mounted) return;
    setState(() {
      _items = l;
      _loading = false;
    });
  }

  bool _exists(HistoryItem it) => File(it.path).existsSync();

  void _open(HistoryItem it) {
    if (!_exists(it)) {
      showGlassToast(
        context,
        'File cache sudah dihapus (salinan tetap ada di galeri/Musik)',
        icon: Icons.info_outline_rounded,
      );
      return;
    }
    if (it.kind == 'image') {
      showDialog<void>(
        context: context,
        barrierColor: Colors.black87,
        builder: (_) => GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: InteractiveViewer(child: Image.file(File(it.path))),
              ),
            ),
          ),
        ),
      );
      return;
    }
    PlayerSheet.show(
      context,
      filePath: it.path,
      title: it.title,
      audio: it.kind == 'audio',
    );
  }

  Future<void> _share(HistoryItem it) async {
    if (!_exists(it)) {
      showGlassToast(context, 'File tidak ditemukan');
      return;
    }
    try {
      await Share.shareXFiles([XFile(it.path)], text: it.title);
    } catch (e) {
      if (mounted) showGlassToast(context, 'Gagal membagikan: $e');
    }
  }

  Future<void> _delete(HistoryItem it) async {
    await HistoryStore.remove(it);
    if (mounted) showGlassToast(context, 'Dihapus dari riwayat');
  }

  IconData _kindIcon(String k) => k == 'audio'
      ? Icons.music_note_rounded
      : (k == 'image' ? Icons.image_rounded : Icons.videocam_rounded);

  String _kindLabel(String k) =>
      k == 'audio' ? 'MP3' : (k == 'image' ? 'Foto' : 'Video');

  Widget _thumb(HistoryItem it) {
    Widget fallback() => Container(
          color: Colors.white12,
          child: Icon(_kindIcon(it.kind), color: Colors.white70),
        );
    Widget child;
    if (it.kind == 'image' && _exists(it)) {
      child = Image.file(File(it.path), fit: BoxFit.cover, cacheWidth: 200);
    } else if (it.kind == 'video' && it.cover.isNotEmpty) {
      child = Image.network(
        it.cover,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => fallback(),
      );
    } else {
      child = fallback();
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: SizedBox(width: 64, height: 64, child: child),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Riwayat',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.w800,
                    shadows: [Shadow(blurRadius: 12, color: Colors.black38)],
                  ),
                ),
              ),
              if (_items.isNotEmpty)
                GlassButton(
                  label: 'Hapus semua',
                  icon: Icons.delete_sweep_rounded,
                  compact: true,
                  expand: false,
                  onTap: () async {
                    for (final it in List<HistoryItem>.from(_items)) {
                      try {
                        final f = File(it.path);
                        if (await f.exists()) await f.delete();
                      } catch (_) {}
                    }
                    await HistoryStore.clear();
                  },
                ),
            ],
          ),
          const SizedBox(height: 14),
          Expanded(child: _body()),
        ],
      ),
    );
  }

  Widget _body() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator(color: Colors.white));
    }
    if (_items.isEmpty) {
      return Align(
        alignment: Alignment.topCenter,
        child: GlassBox(
          radius: 24,
          padding: const EdgeInsets.all(24),
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.inbox_rounded, size: 40, color: Colors.white),
              SizedBox(height: 10),
              Text(
                'Belum ada unduhan',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                ),
              ),
              SizedBox(height: 4),
              Text(
                'Video, MP3, dan foto yang kamu unduh akan muncul di sini.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70),
              ),
            ],
          ),
        ),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.only(bottom: 130),
      itemCount: _items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) {
        final it = _items[i];
        return GestureDetector(
          onTap: () => _open(it),
          child: GlassBox(
            radius: 22,
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                _thumb(it),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        it.title.isEmpty ? '(tanpa judul)' : it.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${_kindLabel(it.kind)} • ${fmtDate(it.time)}',
                        style: const TextStyle(color: Colors.white70, fontSize: 11),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'Bagikan',
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.ios_share_rounded, color: Colors.white),
                  onPressed: () => _share(it),
                ),
                IconButton(
                  tooltip: 'Hapus',
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.delete_outline_rounded, color: Colors.white),
                  onPressed: () => _delete(it),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
