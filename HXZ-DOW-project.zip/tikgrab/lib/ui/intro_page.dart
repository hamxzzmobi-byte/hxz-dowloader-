import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import 'glass.dart';
import 'home_shell.dart';

/// Intro: video no. 2 (full screen 9:16), lalu pindah otomatis ke beranda.
class IntroPage extends StatefulWidget {
  const IntroPage({super.key});

  @override
  State<IntroPage> createState() => _IntroPageState();
}

class _IntroPageState extends State<IntroPage>
    with SingleTickerProviderStateMixin {
  late final VideoPlayerController _c;
  late final AnimationController _fade;
  bool _ready = false;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _fade = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    );
    _c = VideoPlayerController.asset('assets/intro.mp4');
    _init();
  }

  Future<void> _init() async {
    try {
      await _c.initialize();
      await _c.setLooping(false);
      _c.addListener(_tick);
      await _c.play();
      if (!mounted) return;
      setState(() => _ready = true);
      _fade.forward();
    } catch (_) {
      _go();
    }
  }

  void _tick() {
    final v = _c.value;
    if (v.hasError) {
      _go();
      return;
    }
    if (v.isInitialized &&
        v.duration > Duration.zero &&
        v.position >= v.duration - const Duration(milliseconds: 120)) {
      _go();
    }
  }

  void _go() {
    if (_done || !mounted) return;
    _done = true;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 700),
        pageBuilder: (_, __, ___) => const HomeShell(),
        transitionsBuilder: (_, a, __, child) =>
            FadeTransition(opacity: a, child: child),
      ),
    );
  }

  @override
  void dispose() {
    _c.removeListener(_tick);
    _c.dispose();
    _fade.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (_ready)
            FittedBox(
              fit: BoxFit.cover,
              clipBehavior: Clip.hardEdge,
              child: SizedBox(
                width: _c.value.size.width,
                height: _c.value.size.height,
                child: VideoPlayer(_c),
              ),
            ),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withValues(alpha: 0.35),
                  Colors.transparent,
                  Colors.transparent,
                  Colors.black.withValues(alpha: 0.65),
                ],
                stops: const [0, 0.25, 0.6, 1],
              ),
            ),
          ),
          SafeArea(
            child: Stack(
              children: [
                Positioned(
                  top: 12,
                  right: 16,
                  child: GlassButton(
                    label: 'Lewati',
                    icon: Icons.skip_next_rounded,
                    compact: true,
                    expand: false,
                    onTap: _go,
                  ),
                ),
                Positioned(
                  left: 24,
                  right: 24,
                  bottom: 56,
                  child: FadeTransition(
                    opacity: _fade,
                    child: const Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'HXZ DOW',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 46,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.5,
                            shadows: [Shadow(blurRadius: 18, color: Colors.black54)],
                          ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          'Download video & MP3 TikTok',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            letterSpacing: 0.6,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
