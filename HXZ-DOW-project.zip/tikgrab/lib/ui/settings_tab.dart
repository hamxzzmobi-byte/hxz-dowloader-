import 'package:flutter/material.dart';

import '../services/downloader.dart';
import '../services/history_store.dart';
import '../services/native_media.dart';
import '../services/settings.dart';
import '../util.dart';
import 'glass.dart';

class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});

  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  int _cache = 0;

  @override
  void initState() {
    super.initState();
    _refresh();
    HistoryStore.changes.addListener(_refresh);
  }

  @override
  void dispose() {
    HistoryStore.changes.removeListener(_refresh);
    super.dispose();
  }

  Future<void> _refresh() async {
    final s = await Downloader.cacheSize();
    if (mounted) setState(() => _cache = s);
  }

  Widget _switch({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, color: Colors.white),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  subtitle,
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeTrackColor: kAccent,
            inactiveTrackColor: Colors.white24,
            thumbColor: WidgetStateProperty.all(Colors.white),
            trackOutlineColor: WidgetStateProperty.all(Colors.white30),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppSettings.instance;
    return AnimatedBuilder(
      animation: s,
      builder: (_, __) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 130),
        children: [
          const Text(
            'Setelan',
            style: TextStyle(
              color: Colors.white,
              fontSize: 30,
              fontWeight: FontWeight.w800,
              shadows: [Shadow(blurRadius: 12, color: Colors.black38)],
            ),
          ),
          const SizedBox(height: 14),
          GlassBox(
            radius: 26,
            child: Column(
              children: [
                _switch(
                  icon: Icons.content_paste_search_rounded,
                  title: 'Deteksi link otomatis',
                  subtitle: 'Link TikTok di clipboard langsung diproses',
                  value: s.autoPaste,
                  onChanged: s.setAutoPaste,
                ),
                _switch(
                  icon: Icons.movie_filter_rounded,
                  title: 'Putar intro',
                  subtitle: 'Tampilkan video intro saat app dibuka',
                  value: s.playIntro,
                  onChanged: s.setPlayIntro,
                ),
                _switch(
                  icon: Icons.vibration_rounded,
                  title: 'Getar halus',
                  subtitle: 'Umpan balik saat menekan tombol',
                  value: s.haptics,
                  onChanged: s.setHaptics,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassBox(
            radius: 26,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Penyimpanan',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Video → Movies/HXZ DOW\nMP3 → Music/HXZ DOW\nFoto & cover → Pictures/HXZ DOW',
                  style: TextStyle(color: Colors.white, fontSize: 13, height: 1.4),
                ),
                const SizedBox(height: 12),
                GlassButton(
                  label: _cache > 0
                      ? 'Bersihkan cache (${fmtBytes(_cache)})'
                      : 'Cache kosong',
                  icon: Icons.cleaning_services_rounded,
                  onTap: _cache > 0
                      ? () async {
                          await Downloader.clearCache();
                          await HistoryStore.clear();
                          await _refresh();
                          if (mounted) {
                            showGlassToast(
                              context,
                              'Cache & riwayat dibersihkan. File di galeri tetap aman.',
                              icon: Icons.check_circle_rounded,
                            );
                          }
                        }
                      : null,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          GlassBox(
            radius: 26,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'HXZ DOW v1.0',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Developer: HAMXZZ TAMPHAN\nTikTok: @hamxzz_bejirr\n\nUnduh hanya konten milikmu atau yang sudah mendapat izin kreator. Hormati hak cipta.',
                  style: TextStyle(color: Colors.white, fontSize: 13, height: 1.4),
                ),
                const SizedBox(height: 12),
                GlassButton(
                  label: 'Buka TikTok @hamxzz_bejirr',
                  icon: Icons.open_in_new_rounded,
                  primary: true,
                  onTap: () =>
                      NativeMedia.openUrl('https://www.tiktok.com/@hamxzz_bejirr'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
