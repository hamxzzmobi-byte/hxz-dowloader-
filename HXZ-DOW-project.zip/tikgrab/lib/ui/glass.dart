import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/settings.dart';

const kAccent = Color(0xFF7CC4FF);

/// Latar belakang app: gambar no. 1 (cover, rata bawah supaya karakter tetap terlihat).
class AppBackground extends StatelessWidget {
  const AppBackground({super.key, this.child});
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Image.asset(
          'assets/bg.jpg',
          fit: BoxFit.cover,
          alignment: Alignment.bottomCenter,
          gaplessPlayback: true,
        ),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withValues(alpha: 0.30),
                Colors.transparent,
                Colors.transparent,
                Colors.black.withValues(alpha: 0.30),
              ],
              stops: const [0, 0.30, 0.70, 1],
            ),
          ),
        ),
        if (child != null) child!,
      ],
    );
  }
}

/// Kartu kaca (blur + gradasi transparan + border tipis).
class GlassBox extends StatelessWidget {
  const GlassBox({
    super.key,
    required this.child,
    this.radius = 24,
    this.padding = const EdgeInsets.all(16),
    this.blur = 18,
    this.strength = 1.0,
    this.tint,
  });

  final Widget child;
  final double radius;
  final EdgeInsetsGeometry padding;
  final double blur;
  final double strength;
  final Color? tint;

  @override
  Widget build(BuildContext context) {
    final br = BorderRadius.circular(radius);
    final base = tint ?? Colors.white;
    return ClipRRect(
      borderRadius: br,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: br,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                base.withValues(alpha: (0.30 * strength).clamp(0.0, 1.0)),
                base.withValues(alpha: (0.08 * strength).clamp(0.0, 1.0)),
              ],
            ),
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.38),
              width: 1.1,
            ),
          ),
          child: child,
        ),
      ),
    );
  }
}

/// Tombol kaca dengan animasi tekan + getar halus.
class GlassButton extends StatefulWidget {
  const GlassButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.primary = false,
    this.loading = false,
    this.compact = false,
    this.expand = true,
  });

  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool primary;
  final bool loading;
  final bool compact;
  final bool expand;

  @override
  State<GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<GlassButton> {
  bool _down = false;

  void _set(bool v) {
    if (_down != v) setState(() => _down = v);
  }

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null && !widget.loading;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: enabled ? (_) => _set(true) : null,
      onTapCancel: enabled ? () => _set(false) : null,
      onTapUp: enabled ? (_) => _set(false) : null,
      onTap: enabled
          ? () {
              if (AppSettings.instance.haptics) HapticFeedback.lightImpact();
              widget.onTap!();
            }
          : null,
      child: AnimatedScale(
        scale: _down ? 0.95 : 1.0,
        duration: const Duration(milliseconds: 90),
        child: Opacity(
          opacity: (enabled || widget.loading) ? 1.0 : 0.5,
          child: GlassBox(
            radius: 18,
            blur: 14,
            strength: widget.primary ? 1.6 : 1.0,
            tint: widget.primary ? kAccent : null,
            padding: EdgeInsets.symmetric(
              horizontal: 14,
              vertical: widget.compact ? 10 : 14,
            ),
            child: Row(
              mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (widget.loading)
                  const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white,
                    ),
                  )
                else if (widget.icon != null)
                  Icon(widget.icon, size: 20, color: Colors.white),
                if (widget.label.isNotEmpty &&
                    (widget.loading || widget.icon != null))
                  const SizedBox(width: 8),
                if (widget.label.isNotEmpty)
                  Flexible(
                    child: Text(
                      widget.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        shadows: [Shadow(blurRadius: 6, color: Colors.black26)],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Susun beberapa widget sejajar dengan lebar sama.
Widget glassRow(List<Widget> children, {double gap = 10}) {
  final out = <Widget>[];
  for (var i = 0; i < children.length; i++) {
    if (i > 0) out.add(SizedBox(width: gap));
    out.add(Expanded(child: children[i]));
  }
  return Row(crossAxisAlignment: CrossAxisAlignment.center, children: out);
}

void showGlassToast(
  BuildContext context,
  String msg, {
  IconData icon = Icons.info_outline_rounded,
}) {
  final m = ScaffoldMessenger.maybeOf(context);
  if (m == null) return;
  m.hideCurrentSnackBar();
  m.showSnackBar(
    SnackBar(
      behavior: SnackBarBehavior.floating,
      backgroundColor: Colors.transparent,
      elevation: 0,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 110),
      duration: const Duration(seconds: 3),
      content: GlassBox(
        radius: 18,
        blur: 20,
        strength: 1.3,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            Icon(icon, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
