import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../services/downloader.dart';
import '../services/history_store.dart';
import '../services/native_media.dart';
import '../services/settings.dart';
import '../services/tiktok_api.dart';
import '../util.dart';
import 'glass.dart';
import 'player_sheet.dart';

class DownloadTab extends StatefulWidget {
  const DownloadTab({super.key});

  @override
  State<DownloadTab> createState() => DownloadTabState();
}

class DownloadTabState extends State<DownloadTab> with WidgetsBindingObserver {
  final _ctrl = TextEditingController();

  TikInfo? _info;
  bool _fetching = false;
  String? _error;

  bool _downloading = false;
  String _busyLabel = '';
  double? _progress;
  int _lastPct = -1;
  CancelToken? _cancel;
  String? _lastClip;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkClipboard());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ctrl.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _checkClipboard();
  }

  // ---------------------------------------------------------------- input

  /// Dipanggil saat user membagikan link dari TikTok ke HXZ DOW.
  void handleIncoming(String text, {bool autoStart = false}) {
    final u = TikApi.extractUrl(text) ?? text.trim();
    _ctrl.text = u;
    _lastClip = u;
    if (autoStart) _fetch();
  }

  Future<void> _checkClipboard() async {
    if (!AppSettings.instance.autoPaste || _fetching || _downloading) return;
    try {
      final d = await Clipboard.getData(Clipboard.kTextPlain);
      final t = d?.text;
      if (t == null) return;
      final u = TikApi.extractUrl(t);
      if (u == null || u == _lastClip || u == _ctrl.text.trim()) return;
      _lastClip = u;
      if (!mounted) return;
      _ctrl.text = u;
      await _fetch();
    } catch (_) {}
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text?.trim() ?? '';
    if (t.isEmpty) {
      if (mounted) showGlassToast(context, 'Clipboard kosong');
      return;
    }
    final u = TikApi.extractUrl(t) ?? t;
    setState(() {
      _ctrl.text = u;
      _error = null;
    });
    _lastClip = u;
    if (TikApi.extractUrl(u) != null) await _fetch();
  }

  Future<void> _fetch() async {
    final url = TikApi.extractUrl(_ctrl.text.trim());
    if (url == null) {
      setState(() => _error = 'Link TikTok tidak valid');
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      _fetching = true;
      _error = null;
      _info = null;
    });
    try {
      final info = await TikApi.fetch(url);
      if (!mounted) return;
      setState(() => _info = info);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _fetching = false);
    }
  }

  // ------------------------------------------------------------- download

  String _base(TikInfo i) =>
      'HXZDOW_${safeName(i.authorId.isNotEmpty ? i.authorId : i.author)}_${safeName(i.id)}';

  void _progressUpdate(int got, int total, {double from = 0, double span = 1}) {
    if (!mounted) return;
    if (total <= 0) {
      if (_progress != null) setState(() => _progress = null);
      return;
    }
    final v = from + span * (got / total);
    final pct = (v * 100).floor();
    if (pct != _lastPct) {
      _lastPct = pct;
      setState(() => _progress = v);
    }
  }

  Future<void> _download({
    required String label,
    required String url,
    required String suffix,
    required String ext,
    required String kind,
    required String mime,
    required String where,
  }) async {
    final info = _info;
    if (info == null || _downloading || url.isEmpty) return;
    final cancel = CancelToken();
    setState(() {
      _downloading = true;
      _cancel = cancel;
      _busyLabel = label;
      _progress = 0;
      _lastPct = -1;
    });
    try {
      final dir = await Downloader.cacheDir();
      final name = '${_base(info)}$suffix.$ext';
      final file = await Downloader.download(
        url,
        '${dir.path}/$name',
        cancel: cancel,
        onProgress: (g, t) => _progressUpdate(g, t),
      );
      await NativeMedia.save(path: file.path, name: name, mime: mime, kind: kind);
      await HistoryStore.add(HistoryItem(
        id: info.id,
        title: info.title,
        author: info.author,
        path: file.path,
        kind: kind,
        cover: info.cover,
        time: DateTime.now().millisecondsSinceEpoch,
      ));
      if (mounted) {
        showGlassToast(context, 'Tersimpan di $where',
            icon: Icons.check_circle_rounded);
      }
    } on CancelledException {
      if (mounted) showGlassToast(context, 'Unduhan dibatalkan');
    } catch (e) {
      if (mounted) {
        showGlassToast(context, 'Gagal: $e', icon: Icons.error_outline_rounded);
      }
    } finally {
      if (mounted) {
        setState(() {
          _downloading = false;
          _cancel = null;
          _progress = null;
        });
      }
    }
  }

  Future<void> _downloadPhotos() async {
    final info = _info;
    if (info == null || _downloading || info.images.isEmpty) return;
    final cancel = CancelToken();
    final n = info.images.length;
    setState(() {
      _downloading = true;
      _cancel = cancel;
      _busyLabel = 'Foto 0/$n';
      _progress = 0;
      _lastPct = -1;
    });
    try {
      final dir = await Downloader.cacheDir();
      for (var i = 0; i < n; i++) {
        if (mounted) setState(() => _busyLabel = 'Foto ${i + 1}/$n');
        final name = '${_base(info)}_${i + 1}.jpg';
        final file = await Downloader.download(
          info.images[i],
          '${dir.path}/$name',
          cancel: cancel,
          onProgress: (g, t) =>
              _progressUpdate(g, t, from: i / n, span: 1 / n),
        );
        await NativeMedia.save(
            path: file.path, name: name, mime: 'image/jpeg', kind: 'image');
        if (i == 0) {
          await HistoryStore.add(HistoryItem(
            id: info.id,
            title: n > 1 ? '${info.title} ($n foto)' : info.title,
            author: info.author,
            path: file.path,
            kind: 'image',
            cover: info.cover,
            time: DateTime.now().millisecondsSinceEpoch,
          ));
        }
      }
      if (mounted) {
        showGlassToast(context, '$n foto tersimpan di Pictures/HXZ DOW',
            icon: Icons.check_circle_rounded);
      }
    } on CancelledException {
      if (mounted) showGlassToast(context, 'Unduhan dibatalkan');
    } catch (e) {
      if (mounted) {
        showGlassToast(context, 'Gagal: $e', icon: Icons.error_outline_rounded);
      }
    } finally {
      if (mounted) {
        setState(() {
          _downloading = false;
          _cancel = null;
          _progress = null;
        });
      }
    }
  }

  // ------------------------------------------------------------------ UI

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 130),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _header(),
          const SizedBox(height: 10),
          _devPill(),
          const SizedBox(height: 18),
          _inputCard(),
          if (_error != null) ...[
            const SizedBox(height: 12),
            _errorCard(_error!),
          ],
          if (_downloading) ...[
            const SizedBox(height: 12),
            _progressCard(),
          ],
          if (_info != null) ...[
            const SizedBox(height: 12),
            _resultCard(_info!),
          ],
          if (_info == null && !_fetching && _error == null) ...[
            const SizedBox(height: 12),
            _tipCard(),
          ],
        ],
      ),
    );
  }

  Widget _devPill() {
    return Align(
      alignment: Alignment.centerLeft,
      child: GestureDetector(
        onTap: () => NativeMedia.openUrl('https://www.tiktok.com/@hamxzz_bejirr'),
        child: GlassBox(
          radius: 22,
          blur: 14,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.verified_rounded, size: 16, color: Colors.white),
              SizedBox(width: 6),
              Flexible(
                child: Text(
                  'Dev: HAMXZZ TAMPHAN  •  TikTok @hamxzz_bejirr',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header() {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'HXZ DOW',
          style: TextStyle(
            color: Colors.white,
            fontSize: 36,
            fontWeight: FontWeight.w800,
            letterSpacing: 1,
            shadows: [Shadow(blurRadius: 14, color: Colors.black38)],
          ),
        ),
        SizedBox(height: 2),
        Text(
          'Video tanpa watermark  •  MP3  •  Cover  •  Foto',
          style: TextStyle(
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.w500,
            shadows: [Shadow(blurRadius: 8, color: Colors.black45)],
          ),
        ),
      ],
    );
  }

  Widget _inputCard() {
    return GlassBox(
      radius: 28,
      strength: 1.1,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white24),
            ),
            child: TextField(
              controller: _ctrl,
              keyboardType: TextInputType.url,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _fetch(),
              onChanged: (_) => setState(() {}),
              cursorColor: Colors.white,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Tempel link TikTok di sini…',
                hintStyle: const TextStyle(color: Colors.white60),
                border: InputBorder.none,
                prefixIcon: const Icon(Icons.link_rounded, color: Colors.white70),
                suffixIcon: _ctrl.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close_rounded, color: Colors.white70),
                        onPressed: () => setState(() {
                          _ctrl.clear();
                          _info = null;
                          _error = null;
                        }),
                      ),
                contentPadding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          ),
          const SizedBox(height: 12),
          glassRow([
            GlassButton(
              label: 'Tempel',
              icon: Icons.content_paste_rounded,
              onTap: _downloading ? null : _paste,
            ),
            GlassButton(
              label: 'Cari',
              icon: Icons.search_rounded,
              primary: true,
              loading: _fetching,
              onTap: _downloading ? null : _fetch,
            ),
          ]),
        ],
      ),
    );
  }

  Widget _tipCard() {
    return GlassBox(
      radius: 20,
      strength: 0.9,
      padding: const EdgeInsets.all(14),
      child: const Row(
        children: [
          Icon(Icons.bolt_rounded, color: Colors.white),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Tips: di TikTok tekan Bagikan → pilih HXZ DOW. Link terdeteksi & diproses otomatis.',
              style: TextStyle(color: Colors.white, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _errorCard(String msg) {
    return GlassBox(
      radius: 20,
      tint: const Color(0xFFFF6B6B),
      strength: 1.3,
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded, color: Colors.white),
          const SizedBox(width: 10),
          Expanded(
            child: Text(msg, style: const TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _progressCard() {
    final p = _progress;
    return GlassBox(
      radius: 22,
      strength: 1.2,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Mengunduh $_busyLabel…',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              Text(
                p == null ? '' : '${(p * 100).floor()}%',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: p,
              minHeight: 8,
              color: Colors.white,
              backgroundColor: Colors.white24,
            ),
          ),
          const SizedBox(height: 12),
          GlassButton(
            label: 'Batal',
            icon: Icons.close_rounded,
            compact: true,
            onTap: () => _cancel?.cancel(),
          ),
        ],
      ),
    );
  }

  Widget _chip(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: Colors.white),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(color: Colors.white, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _resultCard(TikInfo info) {
    final busy = _downloading;
    final hdSize = fmtBytes(info.hdSize);
    final sdSize = fmtBytes(info.sdSize);

    return GlassBox(
      radius: 28,
      strength: 1.1,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: SizedBox(
                  width: 96,
                  height: 128,
                  child: info.cover.isEmpty
                      ? Container(
                          color: Colors.white12,
                          child: const Icon(Icons.movie_rounded, color: Colors.white70),
                        )
                      : Image.network(
                          info.cover,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: Colors.white12,
                            child: const Icon(Icons.movie_rounded,
                                color: Colors.white70),
                          ),
                        ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      info.authorId.isNotEmpty ? '@${info.authorId}' : info.author,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      info.title.isEmpty ? '(tanpa judul)' : info.title,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white, fontSize: 13),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        _chip(Icons.play_arrow_rounded, fmtCount(info.plays)),
                        _chip(Icons.favorite_rounded, fmtCount(info.likes)),
                        _chip(Icons.chat_bubble_rounded, fmtCount(info.comments)),
                        _chip(Icons.share_rounded, fmtCount(info.shares)),
                        if (info.duration > 0)
                          _chip(Icons.timer_rounded, '${info.duration}s'),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (info.musicTitle.isNotEmpty) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(Icons.music_note_rounded, size: 16, color: Colors.white),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    info.musicAuthor.isEmpty
                        ? info.musicTitle
                        : '${info.musicTitle} — ${info.musicAuthor}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                ),
              ],
            ),
          ],
          const SizedBox(height: 14),
          if (info.hasVideo) ...[
            glassRow([
              if (info.hasHd)
                GlassButton(
                  label: hdSize.isEmpty ? 'Video HD' : 'HD  $hdSize',
                  icon: Icons.hd_rounded,
                  primary: true,
                  onTap: busy
                      ? null
                      : () => _download(
                            label: 'video HD',
                            url: info.hdUrl,
                            suffix: '_HD',
                            ext: 'mp4',
                            kind: 'video',
                            mime: 'video/mp4',
                            where: 'Movies/HXZ DOW',
                          ),
                ),
              GlassButton(
                label: info.hasHd
                    ? (sdSize.isEmpty ? 'Video SD' : 'SD  $sdSize')
                    : (sdSize.isEmpty ? 'Video' : 'Video  $sdSize'),
                icon: Icons.videocam_rounded,
                primary: !info.hasHd,
                onTap: busy || info.sdUrl.isEmpty
                    ? null
                    : () => _download(
                          label: 'video',
                          url: info.sdUrl,
                          suffix: '',
                          ext: 'mp4',
                          kind: 'video',
                          mime: 'video/mp4',
                          where: 'Movies/HXZ DOW',
                        ),
              ),
            ]),
            const SizedBox(height: 10),
          ],
          if (info.isPhotoPost) ...[
            GlassButton(
              label: 'Simpan semua foto (${info.images.length})',
              icon: Icons.photo_library_rounded,
              primary: true,
              onTap: busy ? null : _downloadPhotos,
            ),
            const SizedBox(height: 10),
          ],
          glassRow([
            GlassButton(
              label: 'MP3',
              icon: Icons.music_note_rounded,
              primary: !info.hasVideo && !info.isPhotoPost,
              onTap: busy || info.musicUrl.isEmpty
                  ? null
                  : () => _download(
                        label: 'MP3',
                        url: info.musicUrl,
                        suffix: '',
                        ext: 'mp3',
                        kind: 'audio',
                        mime: 'audio/mpeg',
                        where: 'Music/HXZ DOW',
                      ),
            ),
            GlassButton(
              label: 'Cover',
              icon: Icons.image_rounded,
              onTap: busy || info.originCover.isEmpty
                  ? null
                  : () => _download(
                        label: 'cover',
                        url: info.originCover,
                        suffix: '_cover',
                        ext: 'jpg',
                        kind: 'image',
                        mime: 'image/jpeg',
                        where: 'Pictures/HXZ DOW',
                      ),
            ),
          ]),
          if (info.hasVideo) ...[
            const SizedBox(height: 10),
            GlassButton(
              label: 'Pratinjau video',
              icon: Icons.play_circle_outline_rounded,
              onTap: () => PlayerSheet.show(
                context,
                url: info.previewUrl,
                title: info.title,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
