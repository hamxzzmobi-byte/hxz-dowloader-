int _i(dynamic v) => v is num ? v.toInt() : (int.tryParse('$v') ?? 0);
String _s(dynamic v) => v == null ? '' : '$v';

String _abs(String u) {
  if (u.isEmpty) return '';
  if (u.startsWith('//')) return 'https:$u';
  if (u.startsWith('/')) return 'https://www.tikwm.com$u';
  return u;
}

class TikInfo {
  TikInfo({
    required this.id,
    required this.title,
    required this.cover,
    required this.originCover,
    required this.author,
    required this.authorId,
    required this.musicTitle,
    required this.musicAuthor,
    required this.musicUrl,
    required this.sdUrl,
    required this.hdUrl,
    required this.images,
    required this.duration,
    required this.plays,
    required this.likes,
    required this.comments,
    required this.shares,
    required this.sdSize,
    required this.hdSize,
  });

  final String id, title, cover, originCover, author, authorId;
  final String musicTitle, musicAuthor, musicUrl, sdUrl, hdUrl;
  final List<String> images;
  final int duration, plays, likes, comments, shares, sdSize, hdSize;

  bool get isPhotoPost => images.isNotEmpty;
  bool get hasVideo => !isPhotoPost && (sdUrl.isNotEmpty || hdUrl.isNotEmpty);
  bool get hasHd => hdUrl.isNotEmpty && hdUrl != sdUrl;
  String get previewUrl => sdUrl.isNotEmpty ? sdUrl : hdUrl;

  factory TikInfo.fromJson(Map<String, dynamic> d) {
    final a = (d['author'] is Map) ? Map<String, dynamic>.from(d['author'] as Map) : <String, dynamic>{};
    final m = (d['music_info'] is Map) ? Map<String, dynamic>.from(d['music_info'] as Map) : <String, dynamic>{};
    final imgs = <String>[];
    if (d['images'] is List) {
      for (final e in d['images'] as List) {
        final u = _abs(_s(e));
        if (u.isNotEmpty) imgs.add(u);
      }
    }
    final cover = _abs(_s(d['cover']));
    final origin = _abs(_s(d['origin_cover']));
    return TikInfo(
      id: _s(d['id']).isEmpty ? DateTime.now().millisecondsSinceEpoch.toString() : _s(d['id']),
      title: _s(d['title']),
      cover: cover.isNotEmpty ? cover : origin,
      originCover: origin.isNotEmpty ? origin : cover,
      author: _s(a['nickname']),
      authorId: _s(a['unique_id']),
      musicTitle: _s(m['title']),
      musicAuthor: _s(m['author']),
      musicUrl: _abs(_s(d['music']).isNotEmpty ? _s(d['music']) : _s(m['play'])),
      sdUrl: _abs(_s(d['play'])),
      hdUrl: _abs(_s(d['hdplay'])),
      images: imgs,
      duration: _i(d['duration']),
      plays: _i(d['play_count']),
      likes: _i(d['digg_count']),
      comments: _i(d['comment_count']),
      shares: _i(d['share_count']),
      sdSize: _i(d['size']),
      hdSize: _i(d['hd_size']),
    );
  }
}

class HistoryItem {
  HistoryItem({
    required this.id,
    required this.title,
    required this.author,
    required this.path,
    required this.kind,
    required this.cover,
    required this.time,
  });

  final String id, title, author, path, kind, cover;
  final int time;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'author': author,
        'path': path,
        'kind': kind,
        'cover': cover,
        'time': time,
      };

  factory HistoryItem.fromJson(Map<String, dynamic> j) => HistoryItem(
        id: _s(j['id']),
        title: _s(j['title']),
        author: _s(j['author']),
        path: _s(j['path']),
        kind: _s(j['kind']),
        cover: _s(j['cover']),
        time: _i(j['time']),
      );
}
